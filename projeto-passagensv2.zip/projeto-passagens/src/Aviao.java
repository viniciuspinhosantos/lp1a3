
public class Aviao extends Aeronave {
	
	public Passageiro [][]lugares;

	public Aviao(String modelo, int fileiras, int assentos) {
		super(modelo);
		this.lugares = new Passageiro[fileiras][assentos];
	}
	
	public Passageiro getPassageiro(int fileira, int assento) {
		return this.lugares[fileira][assento];
	}
	
	public void setPassageiro(int fileira, int assento, Passageiro pessoa) {
		this.lugares[fileira][assento] = pessoa;
	}
	
	public boolean verificaLugarOcupado(int fileira, int assento) {
		if (lugares[fileira][assento] != null) {
			return true;
		} else {
			return false;
		}
	}
}
