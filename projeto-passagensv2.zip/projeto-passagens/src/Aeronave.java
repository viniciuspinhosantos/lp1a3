
public class Aeronave {

	protected String modelo;
	
	public Aeronave(String modelo) {
		this.setModelo(modelo);
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	
}
