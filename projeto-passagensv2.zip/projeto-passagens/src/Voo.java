
public class Voo {
	private Aviao aeronave;
	private int nro;
	private String data;
	private String horario;
	
	public Voo(Aviao aeronave, int nro, String data, String horario) {
		this.aeronave = aeronave;
		this.nro = nro;
		this.data = data;
		this.horario = horario;
	}
	
	public int getNro() {
		return nro;
	}
	
	public String getData() {
		return data;
	}
	
	public String getHorario() {
		return horario;
	}

}
