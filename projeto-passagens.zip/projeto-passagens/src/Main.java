
public class Main {

	public static void main(String[] args) {

		Aviao aviao;
		Passageiro passageiro;
		
		aviao = new Aviao("Boeing 237xxx", 20, 50);
		passageiro = new Passageiro("Vinicius", "00011122233");
		
		aviao.setPassageiro(0, 0, passageiro);
		
		System.out.println(aviao.modelo);
		System.out.println(aviao.lugares[19][15]);
		System.out.println(aviao.lugares[0][0]);
		System.out.println(aviao.getPassageiro(0, 0));
		
		System.out.println(passageiro.getNome());
		System.out.println(passageiro.getCpf());
		
	}

}
